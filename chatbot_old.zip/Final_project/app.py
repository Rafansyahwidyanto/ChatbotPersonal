"""
Applikasi streamlit chatbot

Cara jalankan:
>>> streamlit run app2.py
"""

import os

import streamlit as st
from langchain.messages import AIMessage
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_google_genai import ChatGoogleGenerativeAI

st.set_page_config(page_title="Rafa Chatbot", page_icon="🤖")
st.title("Rafa Chatbot")
st.markdown("Hi! Saya Rafa. Silahkan chat dengan AI assistant saya ya...")

### API Key processing ###
if os.environ.get("GOOGLE_API_KEY") is None:
    st.markdown("API Key")
    col1, col2 = st.columns([0.8, 0.2])
    with col1:
        api_key = st.text_input(
            "API Key",
            type="password",
            label_visibility="collapsed",
            placeholder="Type your API key...",
        )
    with col2:
        is_api_key_submitted = st.button(
            "Submit",
        )

    if is_api_key_submitted and api_key != "":
        os.environ["GOOGLE_API_KEY"] = api_key
    if os.environ.get("GOOGLE_API_KEY") is None:
        st.stop()

### ==== TAMBAHAN: Use Case & Parameter Kreatif ==== ###
st.sidebar.header("⚙️ Konfigurasi Chatbot")

use_case = st.sidebar.selectbox(
    "Use Case",
    ["Personal Productivity Assistant", "Travel Assistant", "Education Bot", "Customer Service Bot"],
)

gaya_bahasa = st.sidebar.selectbox(
    "Gaya Bahasa",
    ["Santai", "Formal"],
)

domain_map = {
    "Personal Productivity Assistant": ["Umum", "Manajemen Waktu", "Produktivitas Kerja", "Kebiasaan & Habit"],
    "Travel Assistant": ["Umum", "Destinasi Domestik", "Destinasi Internasional", "Budget Travel"],
    "Education Bot": ["Umum", "Matematika", "Bahasa Inggris", "Sains", "Sejarah"],
    "Customer Service Bot": ["Umum", "Keluhan Produk", "Info Layanan", "Panduan Penggunaan"],
}
domain = st.sidebar.selectbox("Domain Pengetahuan", domain_map[use_case])

temperature = st.sidebar.slider("Kreativitas Jawaban (temperature)", 0.0, 1.0, 0.7)

st.sidebar.markdown("---")
st.sidebar.caption("💡 Fitur Rekomendasi")
rekomendasi_map = {
    "Personal Productivity Assistant": [
        "Buatkan jadwal harian yang produktif",
        "Bagaimana cara mengatasi rasa malas?",
        "Tips fokus kerja 2 jam tanpa distraksi",
    ],
    "Travel Assistant": [
        "Rekomendasikan itinerary 3 hari di Bali",
        "Destinasi liburan hemat di Jawa Tengah",
        "Barang apa saja yang wajib dibawa saat traveling?",
    ],
    "Education Bot": [
        "Jelaskan konsep dasar aljabar",
        "Bagaimana cara belajar efektif untuk ujian?",
        "Berikan contoh soal fisika sederhana",
    ],
    "Customer Service Bot": [
        "Bagaimana cara komplain produk yang rusak?",
        "Berapa lama proses pengembalian dana?",
        "Cara menghubungi customer service 24 jam",
    ],
}
rekomendasi_terpilih = None
for saran in rekomendasi_map[use_case]:
    if st.sidebar.button(saran, key=saran):
        rekomendasi_terpilih = saran

st.sidebar.markdown("---")
reset_memory = st.sidebar.button("🔄 Reset Percakapan")

### ==== System prompt dinamis berdasarkan konfigurasi ==== ###
gaya_text = (
    "santai, ramah, boleh gunakan bahasa sehari-hari dan emoji sesekali"
    if gaya_bahasa == "Santai"
    else "formal, sopan, dan profesional"
)

system_prompt_text = (
    f"You are a helpful chatbot acting as a {use_case} with knowledge focus on {domain}. "
    f"Gunakan gaya bahasa {gaya_text}. "
    "Reply to user chat in short message, max 1 paragraph."
)

client = ChatGoogleGenerativeAI(model="gemini-3.1-flash-lite", temperature=temperature)

### Kolom Chat ###
# Bikin chat history kosong jika belum ada, atau reset kalau konfigurasi/tombol reset berubah
current_config = f"{use_case}-{gaya_bahasa}-{domain}"
config_changed = st.session_state.get("chat_config") != current_config

if "chat_history" not in st.session_state or config_changed or reset_memory:
    st.session_state["chat_config"] = current_config
    st.session_state["chat_history"] = [SystemMessage(system_prompt_text)]

# Tampilkan chat history yang ada selama ini
for chat in st.session_state["chat_history"]:
    if type(chat) is SystemMessage:
        continue
    elif type(chat) is HumanMessage:
        role = "User"
    elif type(chat) is AIMessage:
        role = "AI"
    with st.chat_message(role):
        st.markdown(chat.text)

# Minta prompt dari user (bisa dari input manual atau tombol rekomendasi)
user_prompt = st.chat_input("Ask AI")
if rekomendasi_terpilih:
    user_prompt = rekomendasi_terpilih

if not user_prompt:
    st.stop()
st.session_state["chat_history"].append(HumanMessage(user_prompt))

# Tampilkan prompt dari user
with st.chat_message("User"):
    st.markdown(user_prompt)

# Invoke ke AI, ambil response-nya
with st.chat_message("AI"):
    with st.spinner("Rafa sedang mengetik..."):
        response = client.invoke(st.session_state["chat_history"])
        st.markdown(response.text)

st.session_state["chat_history"].append(response)